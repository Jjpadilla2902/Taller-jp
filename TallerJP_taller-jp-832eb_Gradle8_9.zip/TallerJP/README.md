# Taller JP — POS y Gestión Integral Bimoneda (USD / Bs.)
Proyecto nativo Android en Kotlin + Jetpack Compose configurado para el proyecto de Firebase **`taller-jp-832eb`**.

## Características Técnicas del Paquete
- **Proyecto Firebase**: `taller-jp-832eb` (`app/google-services.json` incluido automáticamente en la carpeta `app/`).
- **Gradle 8.9** configurado en `gradle/wrapper/gradle-wrapper.properties`.
- **Plugins y Dependencias Directas**: Sin `libs.versions.toml` para evitar errores de resolución de catálogos.
- **Cámara + ML Kit Barcode Scanning Bundled**: Usa `com.google.mlkit:barcode-scanning:17.3.0` integrado directamente en el APK (no requiere descarga por Google Play Services).
- **10 Módulos Integrados**: Inventario de Repuestos, Clientes, Proveedores, Catálogo de Servicios, Ventas Mixtas, Ventas por Producto, Compras, Gastos de Taller, Nómina y Tasa/Calculadora Bimoneda.